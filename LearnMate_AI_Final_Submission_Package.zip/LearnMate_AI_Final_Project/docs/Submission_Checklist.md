# Submission Checklist
The provided Masterclass 5 instructions identify three items:
- Lean Canvas PDF
- Concept Note
- PowerPoint Presentation

Before uploading, open all three files, confirm the form's accepted file types and size limits, and make sure you can explain the project. Run the app locally if possible and use only the metrics it displays. Do not claim IBM cloud integration or real-world impact.
