import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

st.set_page_config(page_title="LearnMate AI", page_icon="📘", layout="wide")
st.title("📘 LearnMate AI")
st.subheader("Personalized Learning Gap & Practice Recommendation Prototype")
st.caption("Conceptually aligned with SDG 4: Quality Education")

st.info("Educational prototype only. The app uses synthetic demonstration data, not real student records. Outputs are not diagnoses or high-stakes decisions.")

@st.cache_data
def create_demo_data(n=600, seed=42):
    rng = np.random.default_rng(seed)
    study = rng.uniform(0.5, 8.0, n)
    attendance = rng.uniform(45, 100, n)
    previous = rng.uniform(25, 100, n)
    quiz = np.clip(0.35 * previous + 4.5 * study + 0.22 * attendance + rng.normal(0, 10, n), 0, 100)
    labels = ((quiz < 55) | ((attendance < 60) & (previous < 60))).astype(int)
    return pd.DataFrame({
        "study_hours_per_day": study.round(1),
        "attendance_percent": attendance.round(1),
        "previous_score": previous.round(1),
        "recent_quiz_score": quiz.round(1),
        "needs_extra_practice": labels
    })

@st.cache_resource
def fit_demo_model():
    data = create_demo_data()
    features = ["study_hours_per_day", "attendance_percent", "previous_score", "recent_quiz_score"]
    X_train, X_test, y_train, y_test = train_test_split(
        data[features], data["needs_extra_practice"], test_size=0.25,
        random_state=42, stratify=data["needs_extra_practice"]
    )
    model = Pipeline([
        ("scaler", StandardScaler()),
        ("classifier", LogisticRegression(max_iter=1000, random_state=42))
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)
    return data, model, y_test, predictions, accuracy_score(y_test, predictions), classification_report(
        y_test, predictions, output_dict=True, zero_division=0
    ), confusion_matrix(y_test, predictions)

data, model, y_test, predictions, accuracy, report, matrix = fit_demo_model()
dashboard, explore, assess, evaluate = st.tabs(["Dashboard", "Explore Demo Data", "Student Assessment", "Model Evaluation"])

with dashboard:
    c1, c2, c3 = st.columns(3)
    c1.metric("Synthetic demo records", len(data))
    c2.metric("Input features", 4)
    c3.metric("Test accuracy", f"{accuracy:.1%}")
    st.markdown("### Project workflow")
    st.write("Example indicators → data preparation → supervised model → demo classification → general revision suggestions")
    st.markdown("### Feature averages")
    st.bar_chart(data[["study_hours_per_day", "attendance_percent", "previous_score", "recent_quiz_score"]].mean())

with explore:
    st.markdown("### Sample synthetic records")
    st.dataframe(data.head(30), use_container_width=True)
    st.markdown("### Summary statistics")
    st.dataframe(data.describe().round(2), use_container_width=True)
    st.caption("The generated rows and labels are for software demonstration only.")

with assess:
    st.markdown("### Enter example learning indicators")
    left, right = st.columns(2)
    with left:
        study = st.slider("Study hours per day", 0.5, 8.0, 2.5, 0.5)
        attendance = st.slider("Attendance (%)", 45, 100, 75, 1)
    with right:
        previous = st.slider("Previous assessment score (%)", 0, 100, 60, 1)
        quiz = st.slider("Recent quiz score (%)", 0, 100, 52, 1)
    if st.button("Generate learning support plan", type="primary"):
        row = pd.DataFrame([{
            "study_hours_per_day": study, "attendance_percent": attendance,
            "previous_score": previous, "recent_quiz_score": quiz
        }])
        flag = int(model.predict(row)[0])
        probability = float(model.predict_proba(row)[0][1])
        if flag:
            st.warning(f"Demo model suggests extra practice may be helpful (estimated probability: {probability:.0%}).")
        else:
            st.success(f"Demo model did not flag extra practice from these indicators (estimated probability: {probability:.0%}).")
        tips = []
        if quiz < 60:
            tips.append("Review mistakes from the latest quiz.")
        if previous < 60:
            tips.append("Revise foundational concepts before advanced topics.")
        if attendance < 75:
            tips.append("Review approved notes for lessons missed.")
        if study < 2:
            tips.append("Try short, consistent study sessions.")
        if not tips:
            tips.append("Continue regular revision and check understanding with a short practice quiz.")
        st.markdown("#### Suggested next steps")
        for tip in tips:
            st.write(f"- {tip}")
        st.caption("Suggestions are general and should be adapted with a teacher or trusted educator.")

with evaluate:
    st.markdown("### Evaluation on held-out synthetic test data")
    st.metric("Accuracy", f"{accuracy:.3f}")
    st.dataframe(pd.DataFrame(report).T.round(3), use_container_width=True)
    st.write("Confusion matrix (rows = actual, columns = predicted)")
    st.dataframe(pd.DataFrame(matrix, index=["Actual: no extra practice", "Actual: extra practice"],
                              columns=["Predicted: no", "Predicted: yes"]))
    st.caption("Metrics only demonstrate the workflow because the dataset and labels are synthetic; real-world effectiveness has not been measured.")

st.divider()
st.caption("Prepared by Manish Kumar | Machine Learning and Applied AI Internship 2026 | Local prototype")
